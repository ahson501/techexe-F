#!/bin/bash
# workaround for MSYS2 call of date by qmake.
date "+%y%m%d%H"
